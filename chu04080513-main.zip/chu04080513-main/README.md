-虛擬環境安裝-  
1->環境變數  
C:\Users\L104\AppData\Local\Programs\Python\Python310\Scripts  
C:\Users\L104\AppData\Local\Programs\Python\Python310  
  
2->安裝virtualenv  
pip install virtualenv  
virtualenv 取一個名稱  
  
3->啟動  
到虛擬環境Scripts目錄中啟動  
activate  

-相關-  
virtualenv->virtualenv -p python3.10 XXX  
python->https://www.python.org/   
flask->https://flask.palletsprojects.com/en/3.0.x/  
氣象資料開放平臺->https://opendata.cwa.gov.tw  
sqlitebrowser->https://sqlitebrowser.org/dl/  
line_develop->https://developers.line.biz/zh-hant/  
ngrok->https://ngrok.com/  
ECharts->https://echarts.apache.org/zh/index.html  

 
  